"""
Enabale SPI and I2C configuration from raspberry pi configuration setting first
"""

"""
RFID connection:
RFID Card    RPI Pi
3.3v         PIN_1
RST          PIN_22
GND          PIN_39
MISO         PIN_21
MOSI         PIN_19
SCK          PIN_23
SDA          PIN_24

"""

"""
I2C LCD Connection:
LCD PIN      R-PI PIN
GND          PIN_6
VCC          PIN_4
SDA          PIN_3
SCL          PIN_5

"""
"""
GSM Connection:
GSM PIN      R-PI PIN
GND          PIN_9
RXD          PIN_8
"""

"""
Buzzer Connection:
Buzzer PIN      R-PI PIN
Positive          PIN_7
Negative          PIN_14
"""

import xlwt
from xlwt import Workbook
from datetime import date
import xlrd, xlwt
from xlutils.copy import copy as xl_copy
from RPLCD.i2c import CharLCD
import time
import RPi.GPIO as GPIO
from mfrc522 import SimpleMFRC522
import serial

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

Buzzer = 7
GPIO.setup(Buzzer, GPIO.OUT)

rfid = SimpleMFRC522()

lcd = CharLCD(i2c_expander='PCF8574', address=0x27, port=1, cols=16, rows=2, dotsize=8)

card_number1=701449112927
card_number2=769401295205
card_number3=769401295205
already_attendance_taken = 0
database = {
            card_number1: ['Rahul',"9168948140",card_number1,already_attendance_taken],
            card_number2: ['Shubham',"9763365197",card_number2,already_attendance_taken],
            card_number3: ['xyz',"9763365197",card_number2,already_attendance_taken],
            }

def message_send(number, student_name,lecture_name):
        gsm_ser=serial.Serial("/dev/ttyAMA0", baudrate=9600, timeout=1)
        gsm_ser.write("AT+CMGF=1\r\n".encode());    #Sets the GSM Module in Text Mode
        time.sleep(1);  # time.sleep of 1 milli seconds or 1 second
        gsm_ser.write(("AT+CMGS=\"+91"+number+"\"\r\n").encode()); # Replace x with mobile number
        time.sleep(1);
        gsm_ser.write(("Your Son/Daughter "+student_name+" attended today's "+lecture_name+" class"+"\r\n").encode());
        time.sleep(1);
        gsm_ser.write("\x1A".encode());# ASCII code of CTRL+Z
        time.sleep(1);
        print("Message Send")
        
lcd.clear()
lcd.write_string('RFID Attendance')
lcd.crlf()
lcd.write_string('System')
time.sleep(1)

lcd.clear()
lcd.write_string('Please Enter')
lcd.crlf()
lcd.write_string('Lecture Name')
excel_file_name = 'attendance_excel.xls'
rb = xlrd.open_workbook(excel_file_name, formatting_info=True) 
wb = xl_copy(rb)
lecture_name = input('Please give current subject lecture name')
sheet1 = wb.add_sheet(lecture_name)
sheet1.write(0, 0, 'Name/Date')
sheet1.write(0, 1, str(date.today()))
row=1
col=0
already_attendence_taken = ""
lcd.clear()
lcd.write_string('Lecture Name')
lcd.crlf()
lcd.write_string(lecture_name)
time.sleep(2)
        
while(1):
    lcd.clear()
    lcd.write_string('Scan Your')
    lcd.crlf()
    lcd.write_string('Card')
    time.sleep(1)    
    id, text = rfid.read()
    print(id)
    if(database[id][3] == 0):
            lcd.clear()
            lcd.write_string('Your Attendance')
            lcd.crlf()
            lcd.write_string('Taken '+database[id][0])
            time.sleep(1)
            GPIO.output(Buzzer, True)
            time.sleep(1)
            GPIO.output(Buzzer, False)
            time.sleep(1)
            lcd.clear()
            lcd.write_string('Message send')
            lcd.crlf()
            lcd.write_string('to parent')
            message_send(database[id][1],database[id][0],lecture_name)
            sheet1.write(row, col,database[id][0] )
            col =col+1
            sheet1.write(row, col, "Present" )
            row = row+1
            col = 0
            wb.save(excel_file_name)
            database[id][3] = 1
    else:
            lcd.clear()
            lcd.write_string('Attendance ')
            lcd.crlf()
            lcd.write_string('already Taken ')
            time.sleep(1)      
    

    
